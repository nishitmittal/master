#!/bin/sh

#stamp
python3 cmain.py -m stamp_cikm -d cikm16 -n

python3 cmain.py -m stamp_rsc -d rsc15_64 -n 

python3 cmain.py -m stamp_rsc -d rsc15_4 -n


